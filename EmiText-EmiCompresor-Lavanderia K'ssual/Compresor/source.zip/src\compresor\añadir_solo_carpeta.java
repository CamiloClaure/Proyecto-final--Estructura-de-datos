/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package compresor;

import java.io.File;
import java.util.ArrayList;
import net.lingala.zip4j.core.ZipFile;
import net.lingala.zip4j.exception.ZipException;
import net.lingala.zip4j.model.ZipParameters;
import net.lingala.zip4j.util.Zip4jConstants;

/**
 *
 * @author Jaque
 */
public class añadir_solo_carpeta {

    public añadir_solo_carpeta() {
         try{
             ZipFile archivo=new ZipFile("D:/Compresion/pruebafilla.zip");
      
        String carpeta="D:/Compresion/pruebafilla";
          ZipParameters parametros=new ZipParameters();
          parametros.setCompressionMethod(Zip4jConstants.COMP_DEFLATE);
          parametros.setCompressionLevel(Zip4jConstants.DEFLATE_LEVEL_NORMAL);
          parametros.setEncryptFiles(true);
          parametros.setEncryptionMethod(Zip4jConstants.ENC_METHOD_STANDARD);
       //  parametros.setCompressionLevel(Zip4jConstants.DEFLATE_LEVEL_NORMAL);
          parametros.setPassword("789");
          archivo.addFolder(carpeta, parametros);
      /*  ZipFile archivo=new ZipFile("D:/Compresion/prueba6.zip");
        ArrayList lista=new ArrayList();
        lista.add(new File("D:/Compresion/lol.txt"));
    
        ZipParameters parametros=new ZipParameters();
        parametros.setCompressionMethod(Zip4jConstants.COMP_DEFLATE);
        parametros.setCompressionLevel(Zip4jConstants.DEFLATE_LEVEL_NORMAL);
        
        archivo.addFiles(lista, parametros);*/
        }catch(ZipException e)
        {
        e.printStackTrace();
        }
    }
       public static void main(String[] args){
       
           new añadir_solo_carpeta();
    
    }
        
    }
    

